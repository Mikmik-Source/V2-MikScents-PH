# Mik Scents PH: shop and owner console

Two self-contained web pages with no build step and no server. Upload the folder and it runs.

| Path | What it is |
|---|---|
| `index.html` | The shop: catalogue, filters, testers, cart, checkout, membership, customer profile, terms |
| `admin/index.html` | The owner console: dashboard, orders, shipments, to buy, products, showcase images, suppliers, customers, membership, settings |
| `bottle-*.png`, `logo.png` | Product photos (backgrounds removed) and the logo |

## Publish on GitHub Pages

1. Create a repository and upload everything in this folder (keep `admin/` as a subfolder).
2. Go to **Settings → Pages → Build and deployment**, choose **Deploy from a branch**, branch `main`, folder `/ (root)`.
3. After a minute or so the shop is live at `https://<username>.github.io/<repo>/` and the console at `.../admin/`.

To test locally, run `python3 -m http.server 8000` in this folder and open <http://localhost:8000>.

## Before going live: fill these in

**`index.html` (shop)**
- `SHOP_MESSENGER` and `SHOP_EMAIL`, near `function viewDone`. Fill these in so the order page can show *Open Messenger* and *Email it to us* buttons. Without them, customers can only copy their order details.
- The legal pages still have `[BRACKETED]` placeholders: registered business name, city, contact email, date and reservation amount.
- `BEST_PICKS` sets the bottles shown in *Best sellers this month*. Right now they are Torino 21, Dubai Musk and Decision.
- These prices are placeholders:
  - Torino 21 (₱9,900) and Decision (₱13,900).
  - Tester prices, which are 90% of full price (`TESTER_SEED`).
  - Reseller and Golden prices, which are 10% and 15% off (`TIER_SEED`).

**Console**
- In Settings, enter the GCash name and number and the bank account.

## How sign-in works (no server yet)

**Shop accounts.** Customers register with name, email, password and mobile. The account is saved in that browser, with the password stored as a SHA-256 hash, and stays signed in after a refresh. A wrong password or unknown email is refused. Accounts don't follow a customer to another phone or computer until a real backend is added.

**Console.** The first time you open `/admin/` in a browser, it asks you to set an owner email and password. After that, only that password opens it in that browser. In *Accounts* you can add admins with their own password. Admins see orders, shipments, tickets and customers, but no revenue or pricing. Don't lose the owner password, because there is no reset.

## What works, and what needs a backend later

Works now:
- Browsing, filters, testers, product pages with **Buy now** and **Add to cart**, cart, and checkout. Checkout checks for a valid PH mobile number, and cash on delivery is limited to Metro Manila ready-to-ship orders.
- Customer profile: orders, concerns, photo, Facebook link, and a saved delivery address that fills in checkout.
- Membership: **Join now** goes to the application form, which is pre-filled when signed in. The application is remembered and shows as *under review*.
- Members-only bottles can't be bought by non-members.
- The cart reprices automatically if someone signs in or out.
- The browser Back button, refresh, and links to individual pages (for example `#/product/xerjoff-torino21`) all work.
- Console:
  - Order statuses: **Pending → Confirmed → In transit → Fulfilled**, plus Cancelled.
  - Payments with screenshots.
  - The To buy list, grouped by supplier.
  - Daily sales and the revenue dashboard.
  - Excel and CSV downloads.

Needs a backend (for example Firebase or Supabase):
- **Orders reaching the console.** An order is saved in the customer's browser. The order page asks the customer to send it to you, so set `SHOP_MESSENGER` and `SHOP_EMAIL`.
- **Approving resellers.** Applications and reseller or Golden status can't sync from the console to customers yet.
- **Price secrecy.** Reseller and Golden prices are visible in the page source.
- **One shared database.** Console data lives in the browser you use it in. Download the Excel backup regularly.
